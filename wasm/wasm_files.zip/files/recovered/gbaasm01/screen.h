@define MODE_0 0x00
@define MODE_1 0x01
@define MODE_2 0x02
@define MODE_3 0x03
@define MODE_4 0x04
@define MODE_5 0x05

@define BACKBUFFER 0x010
@define H_BLANK_OAM 0x020

@define OBJ_MAP_2D 0x00
@define OBJ_MAP_1D 0x040

@define FORCE_BLANK 0x080

@define BG0_ENABLE 0x0100
@define BG1_ENABLE 0x0200 
@define BG2_ENABLE 0x0400
@define BG3_ENABLE 0x0800
@define OBJ_ENABLE 0x01000 
@define WIN1_ENABLE 0x02000 
@define WIN2_ENABLE 0x04000
@define WINOBJ_ENABLE 0x08000
@define VRAM 0x06000000
@define VPAL 0x05000000
@define REG_DISPCNT 0x04000000
;VRAM
;	@DCD 0x06000000	;video ram address
;REG_DISPCNT 
;	@DCD 0x04000000 ;screenmode reg.

