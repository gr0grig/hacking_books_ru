;
;    Aplicacion de ejemplo
;    Lo unico que hace es poner una ventana con informacion y un boton para cerrar
;    Compilar con FASM para Menuet
;

use32

                org     0x0

                db      'MENUET00'              ; id de 8 bytes
                dd      38                      ; os requerido
                dd      START                   ; Aqui empuieza el programa
                dd      I_END                   ; Tama�o de la imgen del programa
                dd      0x100000                ; Cantidad de memoria requerida
                                                ; esp = 0x7FFF0
                dd      0x00000000              ; reservado=no no cabecera extendida.



START:                          ; Empieza la ejecucion del programa

    call draw_window            ; Primero, dibujamos la ventana

still:

    mov  eax,10                 ; Esperamos algun evento
    int  0x40

    cmp  eax,1                  ; Peticion para redibujar?
    je   red
    cmp  eax,2                  ; Alguna tecla en el buffer?
    je   key
    cmp  eax,3                  ; Algun boton en el buffer?
    je   button

    jmp  still

  red:                          ; Redibujar
    call draw_window
    jmp  still

  key:                          ; Tecla
    mov  eax,2                  ; Solo la leemos y la ignoramos
    int  0x40
    jmp  still

  button:                       ; boton
    mov  eax,17                 ; obtenemos la id
    int  0x40

    cmp  ah,1                   ; boton id=1 ?
    jne  noclose
    mov  eax,-1                 ; Si es asi cierra el programa
    int  0x40
  noclose:

    jmp  still


;   *********************************************
;   *******  DEFINICION DE LA VENTANA  **********
;   *********************************************


draw_window:

    mov  eax,12                    ; funcion 12:le dice al OS que windowsdraw existe
    mov  ebx,1                     ; 1, Empiesa a dibujar
    int  0x40

                                   ; DIBUJA LA VENTANA:
    mov  eax,0                     ; funcion 0 : define y dibuja la ventana
    mov  ebx,100*65536+300         ; [x empieso] *65536 + [x tama�o]
    mov  ecx,100*65536+120         ; [y empieso] *65536 + [y tama�o]
    mov  edx,0x001111cc            ; color area del trabajo RRGGBB,8->color glide
    mov  esi,0x8099bbff            ; color de la barra  RRGGBB,8->color glide
    mov  edi,0x00ffffff            ; color del frame    RRGGBB
    int  0x40

                                   ; ETIQUETA DE LA VENTANA
    mov  eax,4                     ; function 4 : Escribe texto en la ventana
    mov  ebx,8*65536+8             ; [x start] *65536 + [y start]
    mov  ecx,0x00ffffff            ; color of text RRGGBB
    mov  edx,labelt                ; Puntero al principio del texto
    mov  esi,labellen-labelt       ; Longitud del texto
    int  0x40

                                   ; BOTON DE CERRAR
    mov  eax,8                     ; function 8 : define y dibuja el boton
    mov  ebx,(300-19)*65536+12     ; [x start] *65536 + [x size]
    mov  ecx,5*65536+12            ; [y start] *65536 + [y size]
    mov  edx,1                     ; button id
    mov  esi,0x5599cc              ; button color RRGGBB
    int  0x40


    mov  ebx,25*65536+35           ; Pone el texto con la funcion 4
    mov  ecx,0xffffff
    mov  edx,text
    mov  esi,40
  newline:
    mov  eax,4
    int  0x40
    add  ebx,10
    add  edx,40
    cmp  [edx],byte 'x'
    jne  newline


    mov  eax,12                    ; function 12:Le dice al os ke windows draw existe
    mov  ebx,2                     ; 2, termina de dibujar
    int  0x40

    ret


; Area de datos


text:
    db 'ESTE ES UN EJEMPLO DE UNA APLICACION    '
    db 'EN MENUETOS, ESTA APLICACION ESTA BAJO  '
    db 'GPL, PARA VER EL USO DE LAS FUNCIONES:  '
    db 'SYSFUNCS.TXT Y COMANDOS EN CMD.TXT      '

    db 'x <-MARCADOR PARA TERMINAR, NO LO BORRES'


labelt:
     db   'APLICACION DE EJEMPLO'
labellen:

I_END:


; YA ESTA... CHEKA LA DOCUMENTACION QUE VIENE EN EL FLOPPY... QUIZA DESPUES ME HABIENTE LA
; TRADUCCION DE SYSFUNC.TXT Y DE CMD.TXT
; SSH.... CUALQUIER COMENTARIO A ssh04@linuxmail.org
