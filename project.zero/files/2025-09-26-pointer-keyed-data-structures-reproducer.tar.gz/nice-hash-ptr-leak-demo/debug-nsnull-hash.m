@import Foundation;
int main() {
  @autoreleasepool {
    unsigned long long null_hashval = [[NSNull null] hash];
    printf("null singleton pointer = %p, null_hash = 0x%016llx\n", [NSNull null], null_hashval);
  }
  return 0;
}
